Official arXiv LaTeX source download

Requested URL: https://arxiv.org/src/2607.11021v2
Final URL: https://arxiv.org/src/2607.11021v2
Content-Type: application/gzip
Original source SHA-256: c7f7ecee126504c10a19475498ba6433214885a1874e7751a2668cdbdf58597d

The original response is preserved in original-arxiv-source.tar.gz.
The source/ folder contains its files with their original bytes.
Archive member names were checked and no source was executed or compiled.
