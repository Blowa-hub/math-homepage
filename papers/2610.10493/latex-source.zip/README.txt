Official arXiv LaTeX source download

Requested URL: https://arxiv.org/src/2610.10493v1
Final URL: https://arxiv.org/src/2610.10493v1
Content-Type: application/gzip
Original source SHA-256: b18e7858720738746e052fd014982099104cf9d88b6cba0c44fe5b8160d6b895

The original response is preserved in original-arxiv-source.tar.gz.
The source/ folder contains its files with their original bytes.
Archive member names were checked and no source was executed or compiled.
