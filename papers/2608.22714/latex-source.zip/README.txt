Official arXiv LaTeX source download

Requested URL: https://arxiv.org/src/2608.22714v3
Final URL: https://arxiv.org/src/2608.22714v3
Content-Type: application/gzip
Original source SHA-256: f23ab4d557b4910106122bbe1f7a1de549f208dece483800eb388c99a3dcc448

The original response is preserved in original-arxiv-source.tar.gz.
The source/ folder contains its files with their original bytes.
Archive member names were checked and no source was executed or compiled.
