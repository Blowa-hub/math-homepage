Official arXiv LaTeX source download

Requested URL: https://arxiv.org/src/2609.28089v2
Final URL: https://arxiv.org/src/2609.28089v2
Content-Type: application/gzip
Original source SHA-256: f6122c9c598e42198097191472aef2b8668cb0ce3474378c9baac3ba0fdc9f91

The original response is preserved in original-arxiv-source.tar.gz.
The source/ folder contains its files with their original bytes.
Archive member names were checked and no source was executed or compiled.
