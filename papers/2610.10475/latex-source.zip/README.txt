Official arXiv LaTeX source download

Requested URL: https://arxiv.org/src/2610.10475v1
Final URL: https://arxiv.org/src/2610.10475v1
Content-Type: application/gzip
Original source SHA-256: 3af2782f691b3dd85441350bf444a118bee4cc850525a04eaf1d885db6eded8c

The original response is preserved in original-arxiv-source.tar.gz.
The source/ folder contains its files with their original bytes.
Archive member names were checked and no source was executed or compiled.
